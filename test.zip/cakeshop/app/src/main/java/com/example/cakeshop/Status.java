package com.example.cakeshop;

public class Status {
    static String WAITING   = "Waiting" ;
    static String ACCEPTED  = "Accepted";
    static String DECLINED  = "Declined";
    static String READY_TO_PICKUP = "For picking up"   ;
    static String ON_ITS_WAY      = "Rider on it's way";
    static String SUCCESS         = "Success";
    static  String CANCELED       = "Canceled";
}
