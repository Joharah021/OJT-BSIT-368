package com.example.cakeshop;

public class PaymentMethod {
    static String POP = "Pay on pickup"   ;
    static String COD = "Cash on delivery";
}
